export const courses = [
  {
    id: 1,
    title: "Java Full Stack",
    description: "Master Java Full Stack course, which equips learners...",
    rating: 4.5,
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475"
  },
  {
    id: 2,
    title: "Python Full Stack",
    description: "Master full-stack web development with Python, Django...",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475"
  },
  {
    id: 3,
    title: "Data Science Course",
    description: "Become an expert in Data Science with this course...",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475"
  },
  {
    id: 4,
    title: "MERN Stack Course",
    description: "Master full stack web development with MERN...",
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475"
  },
  {
    id: 5,
    title: "Data Analyst Course",
    description: "Master full stack web development with MERN...",
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475"
  },
    {
    id: 5,
    title: "AI/ML Master Course",
    description: "Master full stack web development with MERN...",
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475"
  },
    {
    id: 5,
    title: "Software Testing Course",
    description: "Master full stack web development with MERN...",
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475"
  }
];